<template>
	<div
		v-if="childProjects.length > 0"
		class="subproject-filter"
	>
		<Popup>
			<template #trigger="{ toggle }">
				<XButton
					variant="secondary"
					icon="sitemap"
					:shadow="false"
					class="mis-2"
					@click.prevent.stop="toggle()"
				>
					{{ $t('task.template.subprojects') }}
					<span
						v-if="includeSubprojects"
						class="subproject-badge"
					>
						{{ enabledCount }}/{{ childProjects.length }}
					</span>
				</XButton>
			</template>
			<template #content>
				<Card class="subproject-popup">
					<div class="subproject-toggle-all">
						<FancyCheckbox
							:model-value="includeSubprojects"
							@update:modelValue="toggleAll"
						>
							{{ $t('task.template.includeSubprojects') }}
						</FancyCheckbox>
					</div>
					<div
						v-if="includeSubprojects"
						class="subproject-list"
					>
						<div
							v-for="child in childProjectsWithColors"
							:key="child.id"
							class="subproject-item"
						>
							<FancyCheckbox
								:model-value="!excludedIds.has(child.id)"
								@update:modelValue="toggleProject(child.id, $event)"
							>
								<span class="subproject-label">
									<span
										class="subproject-color-dot"
										:style="{ backgroundColor: child.color }"
									/>
									{{ child.title }}
								</span>
							</FancyCheckbox>
						</div>
					</div>
				</Card>
			</template>
		</Popup>

		<!-- Inline legend when subprojects are active -->
		<div
			v-if="includeSubprojects && enabledCount > 0"
			class="subproject-legend"
		>
			<span
				v-for="child in activeLegend"
				:key="child.id"
				class="legend-item"
			>
				<span
					class="legend-dot"
					:style="{ backgroundColor: child.color }"
				/>
				<span class="legend-label">{{ child.title }}</span>
			</span>
		</div>
	</div>
</template>

<script lang="ts" setup>
import {ref, computed, watch} from 'vue'

import Popup from '@/components/misc/Popup.vue'
import Card from '@/components/misc/Card.vue'
import FancyCheckbox from '@/components/input/FancyCheckbox.vue'

import {useSubprojectColors} from '@/composables/useSubprojectColors'

import type {IProject} from '@/modelTypes/IProject'

const props = defineProps<{
	projectId: IProject['id']
}>()

const emit = defineEmits<{
	'update:includeSubprojects': [value: boolean]
	'update:excludeProjectIds': [value: string]
	'update:colorMap': [value: Map<number, string>]
}>()

const projectIdRef = computed(() => props.projectId)
const {childProjects, legend, colorMap} = useSubprojectColors(projectIdRef)

const includeSubprojects = ref(false)
const excludedIds = ref<Set<number>>(new Set())

const childProjectsWithColors = computed(() => {
	return legend.value
})

const enabledCount = computed(() => {
	return childProjects.value.filter(c => !excludedIds.value.has(c.id)).length
})

const activeLegend = computed(() => {
	return legend.value.filter(c => !excludedIds.value.has(c.id))
})

function toggleAll(enabled: boolean) {
	includeSubprojects.value = enabled
	if (!enabled) {
		excludedIds.value = new Set()
	}
	emitUpdate()
}

function toggleProject(id: number, enabled: boolean) {
	const newSet = new Set(excludedIds.value)
	if (enabled) {
		newSet.delete(id)
	} else {
		newSet.add(id)
	}
	excludedIds.value = newSet
	emitUpdate()
}

function emitUpdate() {
	emit('update:includeSubprojects', includeSubprojects.value)
	emit('update:excludeProjectIds', Array.from(excludedIds.value).join(','))
	emit('update:colorMap', includeSubprojects.value ? colorMap.value : new Map())
}

watch(() => props.projectId, () => {
	includeSubprojects.value = false
	excludedIds.value = new Set()
	emitUpdate()
})
</script>

<style lang="scss" scoped>
.subproject-filter {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	flex-wrap: wrap;
}

.subproject-badge {
	background: var(--primary);
	color: white;
	border-radius: 10px;
	padding: 0 .4rem;
	font-size: .75rem;
	margin-inline-start: .35rem;
}

.subproject-popup {
	min-inline-size: 220px;
	padding: .75rem;
}

.subproject-toggle-all {
	padding-block-end: .5rem;
	border-block-end: 1px solid var(--grey-200);
	margin-block-end: .5rem;
	font-weight: 600;
}

.subproject-list {
	display: flex;
	flex-direction: column;
	gap: .25rem;
}

.subproject-item {
	padding-inline-start: .5rem;
}

.subproject-label {
	display: inline-flex;
	align-items: center;
	gap: .4rem;
}

.subproject-color-dot {
	display: inline-block;
	inline-size: 10px;
	block-size: 10px;
	border-radius: 50%;
	flex-shrink: 0;
}

.subproject-legend {
	display: inline-flex;
	align-items: center;
	gap: .75rem;
	flex-wrap: wrap;
	padding-inline-start: .25rem;
}

.legend-item {
	display: inline-flex;
	align-items: center;
	gap: .25rem;
	font-size: .8rem;
	color: var(--grey-600);
}

.legend-dot {
	display: inline-block;
	inline-size: 8px;
	block-size: 8px;
	border-radius: 50%;
	flex-shrink: 0;
}

.legend-label {
	white-space: nowrap;
}
</style>
