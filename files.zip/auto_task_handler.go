// Vikunja is a to-do list application to facilitate your life.
// Copyright 2018-present Vikunja and contributors. All rights reserved.
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package v1

import (
	"net/http"
	"strconv"

	"code.vikunja.io/api/pkg/db"
	"code.vikunja.io/api/pkg/models"
	user2 "code.vikunja.io/api/pkg/user"

	"github.com/labstack/echo/v4"
)

// TriggerAutoTask manually creates a task from an auto-task template.
// @Summary Trigger auto-task
// @Description Manually creates a task instance from an auto-task template, regardless of schedule.
// @tags autotask
// @Accept json
// @Produce json
// @Security JWTKeyAuth
// @Param id path int true "Auto-task template ID"
// @Success 200 {object} models.Task
// @Failure 404 {object} web.HTTPError "Template not found"
// @Failure 409 {object} web.HTTPError "Open task already exists"
// @Failure 500 {object} models.Message "Internal error"
// @Router /autotasks/{id}/trigger [post]
func TriggerAutoTask(c echo.Context) error {
	templateID, err := strconv.ParseInt(c.Param("autotask"), 10, 64)
	if err != nil {
		return echo.NewHTTPError(http.StatusBadRequest, "Invalid template ID")
	}

	u, err := user2.GetCurrentUser(c)
	if err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError, "Could not get current user")
	}

	s := db.NewSession()
	defer s.Close()

	if err := s.Begin(); err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError, "Could not start transaction")
	}

	task, err := models.TriggerAutoTask(s, templateID, u)
	if err != nil {
		_ = s.Rollback()
		if _, ok := err.(models.ErrAutoTaskTemplateNotFound); ok {
			return echo.NewHTTPError(http.StatusNotFound, err.Error())
		}
		return echo.NewHTTPError(http.StatusConflict, err.Error())
	}

	if err := s.Commit(); err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError, "Could not commit")
	}

	return c.JSON(http.StatusOK, task)
}

// CheckAutoTasks checks all active templates for the current user and creates due tasks.
// @Summary Check and create auto-tasks
// @Description Scans active auto-task templates and creates task instances for any that are due.
// @tags autotask
// @Accept json
// @Produce json
// @Security JWTKeyAuth
// @Success 200 {object} map[string]interface{} "Created tasks"
// @Failure 500 {object} models.Message "Internal error"
// @Router /autotasks/check [post]
func CheckAutoTasks(c echo.Context) error {
	u, err := user2.GetCurrentUser(c)
	if err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError, "Could not get current user")
	}

	s := db.NewSession()
	defer s.Close()

	if err := s.Begin(); err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError, "Could not start transaction")
	}

	created, err := models.CheckAndCreateAutoTasks(s, u)
	if err != nil {
		_ = s.Rollback()
		return echo.NewHTTPError(http.StatusInternalServerError, err.Error())
	}

	if err := s.Commit(); err != nil {
		return echo.NewHTTPError(http.StatusInternalServerError, "Could not commit")
	}

	return c.JSON(http.StatusOK, map[string]interface{}{
		"created": created,
		"count":   len(created),
	})
}
